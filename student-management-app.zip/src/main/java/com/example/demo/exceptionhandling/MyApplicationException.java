package com.example.demo.exceptionhandling;
import java.time.LocalDateTime;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
@ControllerAdvice
public class MyApplicationException {
    @ExceptionHandler(value = StudentNotFoundException.class)
    public ResponseEntity<ExceptionInfo> studentIdNotFound(StudentNotFoundException e) {
        ExceptionInfo info = new ExceptionInfo();
        info.setCode("Ex90001");
        info.setMsg(e.getMessage());
        info.setLocalDateTime(LocalDateTime.now());
        return new ResponseEntity<>(info, HttpStatus.BAD_REQUEST);
    }
}
