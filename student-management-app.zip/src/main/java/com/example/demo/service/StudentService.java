package com.example.demo.service;
import com.example.demo.entity.Student;
import com.example.demo.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
@Service
public class StudentService {
    @Autowired
    private StudentRepository repo;
    public Page<Student> getPaginated(int pageNo, int pageSize) {
        Pageable pageable = PageRequest.of(pageNo - 1, pageSize);
        return repo.findAll(pageable);
    }
    public void save(Student student) {
        repo.save(student);
    }
    public Student getById(Long id) {
        return repo.findById(id).orElse(null);
    }
    public void deleteById(Long id) {
        repo.deleteById(id);
    }
}
